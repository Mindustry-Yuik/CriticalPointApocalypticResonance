const lib = require("base/NCPlib");
const FX = require("base/fightFx");
const NX = require("base/normalFx");
//const {湍能, 坍缩} = require("base/status");



exports.PulseEnergyBulletType = (speed, lifetime, power, B, size, reload) => {
	let range = Math.max(B.speed * B.lifetime, B.length) - 8;
	return extend(BasicBulletType, {
		speed: speed,
		lifetime: lifetime,
		hittable: false,
		collides: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			let target = Units.closestTarget(b.team, b.x, b.y, range);
			if (target != null && b.timer.get(reload)) {
				for (let i = 0; i < 5; i++) Time.run(10 * i, () => {
					let ang = Angles.angle(b.x, b.y, target.x, target.y);
					let xy = lib.AngleTrns(ang, size);
					B.shootEffect.at(xy.x, xy.y, ang, B.hitColor, b);
					let bu = B.create(b, b.x, b.y, ang);
					//FX.chainLightningFade.at(b.x, b.y, Mathf.random(16, 24), lib.FF8663, bu);
				});
			}
			Damage.status(b.team, b.x, b.y, size * 2, 湍能, 60, true, true);
			if (!target && Vars.state.rules.waves && b.team == Vars.state.rules.defaultTeam) {
				let spawn = Geometry.findClosest(b.x, b.y, Vars.spawner.getSpawns()) || b.closestEnemyCore();
				b.vel.setAngle(Angles.moveToward(b.rotation(), b.angleTo(spawn), Time.delta * power));
			}
		},
		draw(b) {
			Draw.blend(Blending.additive);
			Lines.stroke(2);
			let s = Mathf.absin(3, 0.3);
			Draw.color(B.hitColor, 0.7);
			Fill.circle(b.x, b.y, size / 20 + s);
			Lines.circle(b.x, b.y, size / 5 + s);
			Lines.circle(b.x, b.y, size + s);
			let rand = Fx.rand;
			rand.setSeed(b.id);
			Lines.stroke(2.2);
			for (let i = 0; i < size * 2; i++) {
				let fin = (rand.random(1) + Time.time / size) % 1, fout = 1 - fin;
				let len = size * Interp.pow2Out.apply(fin);
				let angle = rand.random(360), xy = lib.AngleTrns(angle, len);
				Lines.lineAngle(b.x + xy.x, b.y + xy.y, angle, 7 * fout);
			}
			Draw.blend();
			Draw.reset();
			let xy = lib.Randonge(b.x, b.y, size * 2);
			if (Vars.state.isPaused() || b.time >= b.lifetime - 26) return
			if (Mathf.chance(0.05)) FX.chainLightningFade.at(xy.x, xy.y, Mathf.random(8, 16), B.hitColor, b);
		}
	})
}

exports.TorrentBulletType = (speed, damage, lifetime, power) => {
	return extend(BasicBulletType, {
		sprite: "circle",
		shrinkY: 0,
		speed: speed,
		damage: damage,
		lifetime: lifetime,
		update(b) {
			this.super$update(b);
			b.vel.setAngle(Angles.moveToward(b.rotation(), b.owner.rotation, Time.delta * power));
		}
	})
}

exports.HomingBulletType = (speed, damage, lifetime, power) => {
	let r, t
	return extend(BasicBulletType, {
		speed: speed,
		damage: damage,
		lifetime: lifetime,
		update(b) {
			this.super$update(b);
			let e = b.owner;
			if (e instanceof Unit) {
				r = e.range;
				t = b.angleTo(e.aimX, e.aimY);
			} else {
				r = e.block.range;
				t = b.angleTo(e.targetPos || b);
			}
			if (b.dst(e) > r * 1.2) b.time = b.lifetime + 1;
			else b.vel.setAngle(Angles.moveToward(b.rotation(), t, Time.delta * power));
		},
		draw(b) {
			this.drawTrail(b);
			Tmp.v1.trns(b.rotation(), b.type.height / 2);
			for (let i of Mathf.signs) {
				Tmp.v2.trns(b.rotation() - 90, b.type.width * i, -b.type.height);
				Draw.color(b.type.backColor);
				Fill.tri(Tmp.v1.x + b.x, Tmp.v1.y + b.y, -Tmp.v1.x + b.x, -Tmp.v1.y + b.y, Tmp.v2.x + b.x, Tmp.v2.y + b.y);
				Draw.color(b.type.frontColor);
				Fill.tri(Tmp.v1.x / 2 + b.x, Tmp.v1.y / 2 + b.y, -Tmp.v1.x / 2 + b.x, -Tmp.v1.y / 2 + b.y, Tmp.v2.x / 2 + b.x, Tmp.v2.y / 2 + b.y);
			}
		}
	})
}

exports.TwiceHomingBulletType = (range) => {
	return extend(BasicBulletType, {
		drag: 0.01,
		shrinkY: 0,
		lifetime: 1800,
		sprite: "circle",
		update(b) {
			this.super$update(b);
			if (b.time < 80 / b.type.speed) return
			let target = Units.closestTarget(b.team, b.x, b.y, range);
			if (target == null) return
			b.vel.trns(Angles.angle(b.x, b.y, target.x, target.y), b.type.speed);
		}
	})
}

exports.FortressBulletType = (range, reload, B, num, random, spread) => {
	if (range == 0) range = Math.min(B.speed * B.lifetime, B.speed * (1 - Mathf.pow(1 - B.drag, B.lifetime)) / B.drag);
	return extend(BasicBulletType, {
		drag: 0.01,
		damage: 0,
		hittable: false,
		collides: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			let target = Units.closestTarget(b.team, b.x, b.y, range);
			if (target != null && b.timer.get(reload)) {
				for (let i = 0; i < num; i++) {
					B.create(b, b.x, b.y, Angles.angle(target.x, target.y, b.x, b.y) + Mathf.range(random || 360) + ((i - (num - 1) / 2) * (spread || 0)));
				}
			}
		},
		draw(b) {
			this.drawTrail(b);
			let size = b.type.height;
			Draw.color(b.type.backColor);
			NX.shiningCircle(b.id, Time.time, b.x, b.y, size, 5, 30, 0, size * 1.5, size, 360);
			Draw.color(b.type.frontColor);
			NX.shiningCircle(b.id, Time.time, b.x, b.y, size * 0.65, 5, 30, 0, size, size * 0.9, 360);
		}
	})
}

exports.RandomLightningBulletType = (damage, range, radius, reload, num, effect) => {
	return extend(BasicBulletType, {
		hittable: false,
		absorbable: false,
		reflectable: false,
		ammoMultiplier: 1,
		update(b) {
			this.super$update(b);
			if (b.time >= b.lifetime - 26) return
			if (b.timer.get(reload)) {
				for (let i = 0; i < num; i++) {
					let xy = lib.Randonge(b.x, b.y, range), x = xy.x, y = xy.y;
					Damage.damage(b.team, x, y, radius, damage);
					Damage.status(null, x, y, radius, 坍缩, 60, true, true);
					FX.chainLightningFadeReversed.at(x, y, Mathf.random(16, 24), lib.FF8663, b);
					Sounds.plasmaboom.at(x, y);
					Effect.shake(4, 30, x, y);
					effect.at(x, y);
				}
			}
		}
	})
}

exports.ArmorBrokenBulletType = (speed, damage, lifetime, percent, num) => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			b.damage = damage + entity.armor * percent;
			entity.armor -= num;
			this.super$hitEntity(b, entity, health);
		},
		speed: speed,
		damage: damage,
		lifetime: lifetime,
		ammoMultiplier: 1,
		pierceArmor: true,
		despawnEffect: Fx.none
	});
}

exports.MindControlBulletType = () => {
	return extend(BasicBulletType, {
		hitEntity(b, entity, health) {
			this.super$hitEntity(b, entity, health);
			if (entity instanceof Unit && entity.healthf() <= 0.05) {
				entity.team = b.team;
				entity.heal();
				Fx.spawn.at(entity.x, entity.y);
			}
		}
	})
}

exports.BlockHoleBulletType = (range, suction /*力度*/ , damage, percent) => {
	return extend(BasicBulletType, {
		shrinkY: 0,
		damage: 0,
		speed: 0,
		hittable: false,
		collides: false,
		absorbable: false,
		reflectable: false,
		ammoMultiplier: 1,
		update(b) {
			this.super$update(b);
			Units.nearbyEnemies(b.team, b.x, b.y, range, u => {
				let dst = 1 - u.dst(b) / range;
				u.impulse(Tmp.v3.set(b).sub(u).nor().scl(80 * suction * (dst + 1)));
				Damage.status(b.team, b.x, b.y, range, 坍缩, 60, true, true);
				u.damageContinuousPierce((u.type.health * percent / (this.lifetime / 60) + damage) * dst / 60);
			})
		},
		draw(b) {
			this.drawTrail(b);
			let xy = lib.Randonge(b.x, b.y, range);
			if (Vars.state.isPaused() || b.time >= b.lifetime - 26) return
			if (Mathf.chance(0.2)) FX.chainLightningFade.at(xy.x, xy.y, Mathf.random(8, 16), lib.FF8663, b);
		}
	})
}

exports.EnergyFieldBulletType = (range, reload, damage, maxTargets, status, statusDuration, color, hitEffect) => {
	let timer = 0, all = new Seq();
	return extend(BasicBulletType, {
		hittable: false,
		absorbable: false,
		reflectable: false,
		update(b) {
			this.super$update(b);
			if ((timer += Time.delta) >= reload) {
				all.clear();
				Units.nearby(null, b.x, b.y, range, other => {
					if (other.team != b.team) all.add(other);
				});
				Units.nearbyBuildings(b.x, b.y, range, build => {
					if (build.team != b.team) all.add(build);
				});
				all.sort(floatf(e => e.dst2(b.x, b.y)));
				let max = Math.min(all.size, maxTargets);
				for (let i = 0; i < max; i++) {
					let other = all.get(i);
					var absorber = Damage.findAbsorber(b.team, b.x, b.y, other.getX(), other.getY());
					if (absorber != null) other = absorber;
					Fx.chainLightning.at(b.x, b.y, 0, color, other);
					if (hitEffect) {
						hitEffect.at(other);
					} else {
						Fx.hitLaserBlast.at(other.x, other.y, b.angleTo(other), color);
					}
					other.damage(damage);
					if (other instanceof Unit) other.apply(status, statusDuration);
					Sounds.spark.at(b);
				}
				timer = 0;
			}
		}
	})
}

exports.PointLaser = (range, speed, rotate) => {
	return extend(PointLaserBulletType, {
		update(b) {
			this.updateTrail(b);
			this.updateHoming(b);
			this.updateWeaving(b);
			this.updateTrailEffects(b);
			this.updateBulletInterval(b);
			let u = b.owner, ang = 0;
			if (u instanceof Unit) {
				let shootLength = Math.min(u.dst(u.aimX, u.aimY), range);
				let curLength = u.dst(b.aimX, b.aimY);
				let resultLength = Mathf.approachDelta(curLength, shootLength, speed);
				if (rotate) {
					ang = Angles.angle(u.x, u.y, u.aimX, u.aimY);
				} else {
					ang = u.rotation;
				}
				Tmp.v1.trns(ang, resultLength).add(u.x, u.y);
				let xy = lib.AngleTrns(ang, range - 1);
				if (curLength > range) {
					b.aimX = u.x + xy.x;
					b.aimY = u.y + xy.y;
				} else {
					b.aimX = Tmp.v1.x;
					b.aimY = Tmp.v1.y;
				}
				if (b.timer.get(0, this.damageInterval)) {
					Damage.collidePoint(b, b.team, this.hitEffect, b.aimX, b.aimY);
				}
				if (b.timer.get(1, this.beamEffectInterval)) {
					this.beamEffect.at(b.aimX, b.aimY, this.beamEffectSize * b.fslope(), this.hitColor);
				}
				if (this.shake != null && this.shake > 0) {
					Effect.shake(this.shake, this.shake, b);
				}
			}
		}
	})
}
