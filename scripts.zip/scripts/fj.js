/*
function createScanButton(text, width, height, scanColor) {
    const button = new Button(Styles.cleart);
    button.scanAnimation = false;
    // 设置按钮文本
    button.add(new Label(text));
    // 设置按钮大小
    button.setSize(width, height);
    // 事件监听器
    button.addListener(new InputListener({
        enter(event, x, y, pointer, fromActor) {
            button.scanAnimation = true;
        },
        exit(event, x, y, pointer, toActor) {
            button.scanAnimation = false;
        }
    }));
    const drawScanEffect = (button) => {
        const width = button.getWidth();
        const height = button.getHeight();
        const x = button.getX();
        const y = button.getY();

        const scanWidth = 20; // 扫描线宽度
        const scanSpeed = 2;  // 扫描速度
        const scanX = (Time.time * scanSpeed) % (width + scanWidth) - scanWidth;

        Draw.color(scanColor || Color.valueOf("ffffff")); // 使用传入的颜色，默认为白色
        Draw.alpha(0.5); // 设置透明度
        const whiteTexture = Core.atlas.find("white");
        if (whiteTexture != null) {
            Draw.rect(whiteTexture, x + scanX, y, scanWidth, height); // 绘制扫描线
        } else {
            Draw.rect(Core.atlas.find("clear"), x + scanX, y, scanWidth, height); // 使用透明纹理作为后备
        }
        Draw.reset(); // 重置颜色和透明度
    };

    button.update(() => {//check the Draw
        if (button.scanAnimation) {
            drawScanEffect(button); // 绘制扫描效果
        }
    });

    return button;
}
//好入，如果你把这个救活了，你是这个👍
Events.run(EventType.ClientLoadEvent, () => {
    const dialog = new BaseDialog("Scan Button Demo");
    dialog.cont.pane(table => {
        const scanButton = createScanButton("Hover Me", 200, 50, Color.valueOf("00ffff")); // 青色
        table.add(scanButton).row();
    }).grow().center();

    dialog.addCloseListener();
    dialog.buttons.button("@back", Icon.left, Styles.cleart, () => {
        dialog.hide();
    }).size(460, 64);

    dialog.show();
});

*/

/*
Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog(Core.bundle.format("Toptitle"));//title最上面的
    kaiping.cont.pane((() => {
        var table = new Table();        
         table.image(Core.atlas.find("iety-Logo")).row();
         table.add("%Power by Yuki CriticalPoint%", Styles.techLabel).row(); 
        table.button('UpdateContent', Icon.paste, Styles.cleart,() => {
        var dialog = new BaseDialog("Update");
        dialog.cont.pane(t => {
        t.add("*UpdateContent*\n", Styles.techLabel).row();
        t.add(Core.bundle.format("UPC")).row();
        });
        dialog.buttons.button("@close", Icon.left, Styles.cleart, ()=>{dialog.hide()}).size(400, 64);;
        dialog.show();
        }).size(620, 64);
        table.row();
        
           return table;
})()).grow().center();
kaiping.addCloseListener();//按esc关闭
kaiping.buttons.button("@back", Icon.left, Styles.cleart, () => {
    kaiping.hide();
}).size(460, 64);
kaiping.show();
}));
//pad(4)可活动量
//wrap()文本超出时可活动/自动换行
*/

Events.on(EventType.ClientLoadEvent, cons(e => {
    var kaiping = new BaseDialog(Core.bundle.format("Toptitle"));

    // 主内容区域保持不变
    kaiping.cont.pane((() => {
        var table = new Table();        
        table.image(Core.atlas.find("iety-Logo")).row();
        table.add("%Power by Yuki CriticalPoint%", Styles.techLabel).row(); 
        table.button('UpdateContent', Icon.paste, Styles.cleart,() => {
            var dialog = new BaseDialog("Update");
            dialog.cont.pane(t => {
                t.add("*UpdateContent*\n", Styles.techLabel).row();
                t.add(Core.bundle.format("UPC")).wrap().row();
            });
            dialog.buttons.button("@close", Icon.left, Styles.cleart, () => dialog.hide()).size(400, 64);
            dialog.show();
        }).size(620, 64);
        return table;
    })()).grow().center();

    kaiping.addCloseListener();
    kaiping.buttons.button("@back", Icon.left, Styles.cleart, () => kaiping.hide()).size(620, 64);
    kaiping.buttons.button('sittings', Icon.paste, Styles.cleart,() => {
            var dialog = new BaseDialog("sittings");
            dialog.cont.pane(t => {
                t.add("%PlayForYourFun%", Styles.techLabel).row();
            });
            dialog.buttons.button("@close", Icon.left, Styles.cleart, () => dialog.hide()).size(400, 64);
            dialog.show();
        }).size(620, 64);
    kaiping.show();
}));
/*
		let time = 5 * 60;
		dialog.buttons.button("", () => {
		Vars.player.unit().heal();
		}).size(45).disabled(b => time > 0).update(b => {
			if (time > 0) {
				time -= Time.delta
				b.setText("(" + parseInt(time / 60) + ")");
			} else {
				b.setText("OK");
				b.update(null);
			}
		}).row(); //打开后5秒允许关闭，显示倒计时
		
		*/
	